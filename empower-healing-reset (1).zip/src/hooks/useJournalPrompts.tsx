import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export interface JournalPrompt {
  id: string;
  title: string;
  prompt_text: string;
  category: string;
  is_premium: boolean;
  pdf_url?: string;
  created_at: string;
}

export function useJournalPrompts(category?: string, premiumOnly?: boolean) {
  const [prompts, setPrompts] = useState<JournalPrompt[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchPrompts();
  }, [category, premiumOnly]);

  const fetchPrompts = async () => {
    try {
      setLoading(true);
      let query = supabase
        .from('journal_prompts')
        .select('*')
        .order('created_at', { ascending: false });

      if (category) {
        query = query.eq('category', category);
      }

      if (premiumOnly !== undefined) {
        query = query.eq('is_premium', premiumOnly);
      }

      const { data, error } = await query;

      if (error) {
        setError(error.message);
        return;
      }

      setPrompts(data || []);
    } catch (err) {
      setError('Failed to fetch journal prompts');
    } finally {
      setLoading(false);
    }
  };

  return {
    prompts,
    loading,
    error,
    refetch: fetchPrompts,
  };
}