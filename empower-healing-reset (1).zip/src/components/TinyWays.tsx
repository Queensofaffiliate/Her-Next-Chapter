import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Heart, CheckCircle2, ArrowRight } from 'lucide-react';

const tinyWays = [
  {
    id: 1,
    title: "Take Three Deep Breaths",
    description: "Pause wherever you are and breathe deeply. Let each breath remind you that you're safe in this moment.",
    category: "Mindfulness"
  },
  {
    id: 2,
    title: "Write One Thing You're Grateful For",
    description: "Even on difficult days, there's always something. It could be as simple as your morning coffee.",
    category: "Gratitude"
  },
  {
    id: 3,
    title: "Send Yourself a Kind Text",
    description: "Write yourself an encouraging message and save it. Read it when you need a gentle reminder.",
    category: "Self-Love"
  },
  {
    id: 4,
    title: "Step Outside for 2 Minutes",
    description: "Fresh air and natural light can shift your energy. Even a brief moment outdoors counts.",
    category: "Nature"
  },
  {
    id: 5,
    title: "Drink a Glass of Water Mindfully",
    description: "Hydrate your body while being present. Feel grateful for this simple act of self-care.",
    category: "Self-Care"
  },
  {
    id: 6,
    title: "Stretch Your Arms Above Your Head",
    description: "Release tension and create space in your body. Let your posture reflect your inner strength.",
    category: "Movement"
  },
  {
    id: 7,
    title: "Look in the Mirror and Smile",
    description: "Meet your own eyes with kindness. You deserve the same compassion you give others.",
    category: "Self-Love"
  },
  {
    id: 8,
    title: "Tidy One Small Space",
    description: "Clear a drawer, organize your desk, or make your bed. External order supports internal peace.",
    category: "Environment"
  },
  {
    id: 9,
    title: "Listen to One Favorite Song",
    description: "Let music lift your spirits. Dance if you feel like it, or simply let the melody wash over you.",
    category: "Joy"
  },
  {
    id: 10,
    title: "Call Someone Who Cares",
    description: "Reach out to a friend or family member. Connection reminds us we're not alone in this journey.",
    category: "Connection"
  }
];

export const TinyWays: React.FC = () => {
  const [completedWays, setCompletedWays] = useState<number[]>([]);

  const toggleComplete = (id: number) => {
    setCompletedWays(prev => 
      prev.includes(id) 
        ? prev.filter(wayId => wayId !== id)
        : [...prev, id]
    );
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-3">
        <h2 className="text-2xl font-bold text-cocoa-brown flex items-center justify-center gap-2">
          <Heart className="h-6 w-6 text-warm-blush" />
          10 Tiny Ways to Feel Better
        </h2>
        <p className="text-cocoa-brown/70 max-w-2xl mx-auto">
          Small acts of self-care that can shift your day. Choose one that feels right for you right now.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {tinyWays.map((way) => (
          <Card 
            key={way.id} 
            className={`transition-all duration-200 hover:shadow-md ${
              completedWays.includes(way.id) 
                ? 'bg-sage-green/10 border-sage-green/30' 
                : 'hover:border-warm-blush/50'
            }`}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-cocoa-brown flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <span className="text-warm-blush font-bold">#{way.id}</span>
                  {way.title}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleComplete(way.id)}
                  className={`${
                    completedWays.includes(way.id)
                      ? 'text-sage-green hover:text-sage-green'
                      : 'text-cocoa-brown/40 hover:text-sage-green'
                  }`}
                >
                  <CheckCircle2 className="h-5 w-5" />
                </Button>
              </CardTitle>
              <div className="text-xs text-warm-blush font-medium">
                {way.category}
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-cocoa-brown/80 text-sm leading-relaxed">
                {way.description}
              </p>
              {!completedWays.includes(way.id) && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => toggleComplete(way.id)}
                  className="mt-3 text-sage-green hover:text-sage-green hover:bg-sage-green/10"
                >
                  Try This Now <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {completedWays.length > 0 && (
        <div className="text-center p-4 bg-sage-green/10 rounded-lg border border-sage-green/20">
          <p className="text-sage-green font-medium">
            ✨ You've completed {completedWays.length} tiny way{completedWays.length !== 1 ? 's' : ''}! 
            Every small step matters on your journey.
          </p>
        </div>
      )}
    </div>
  );
};

export default TinyWays;