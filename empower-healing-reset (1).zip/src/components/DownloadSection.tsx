import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, FileText } from 'lucide-react';
import { useDownloads } from '@/hooks/useDownloads';
import { DownloadableContent } from '@/lib/supabase';
import PremiumGate from './PremiumGate';
import { useSubscription } from '@/hooks/useSubscription';

interface DownloadSectionProps {
  className?: string;
}

export const DownloadSection: React.FC<DownloadSectionProps> = ({ className = '' }) => {
  const { downloads, loading } = useDownloads();
  const { hasFeature } = useSubscription();

  const handleDownload = async (download: DownloadableContent) => {
    try {
      const response = await fetch(download.file_url);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = download.title;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Download failed:', error);
    }
  };

  if (loading) {
    return (
      <div className={`space-y-4 ${className}`}>
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
          <div className="h-20 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  // All downloads are free for now since requires_premium field doesn't exist
  const freeDownloads = downloads;
  const premiumDownloads: any[] = [];

  return (
    <div className={`space-y-6 ${className}`}>
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Free Resources</h3>
        
        {freeDownloads.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center">
              <FileText className="h-12 w-12 mx-auto text-gray-400 mb-2" />
              <p className="text-gray-600">No free downloads available yet.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {freeDownloads.slice(0, hasFeature('unlimited_downloads') ? undefined : 2).map((download) => (
              <Card key={download.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center justify-between">
                    <span>{download.title}</span>
                    <Button size="sm" onClick={() => handleDownload(download)} className="ml-2">
                      <Download className="h-4 w-4 mr-1" /> Download
                    </Button>
                  </CardTitle>
                </CardHeader>
                {download.description && (
                  <CardContent className="pt-0">
                    <p className="text-sm text-gray-600">{download.description}</p>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>

      {premiumDownloads.length > 0 && (
        <PremiumGate feature="unlimited_downloads" featureName="Premium Downloads">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Premium Resources</h3>
            <div className="grid gap-4">
              {premiumDownloads.map((download) => (
                <Card key={download.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center justify-between">
                      <span>{download.title}</span>
                      <Button size="sm" onClick={() => handleDownload(download)} className="ml-2">
                        <Download className="h-4 w-4 mr-1" /> Download
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  {download.description && (
                    <CardContent className="pt-0">
                      <p className="text-sm text-gray-600">{download.description}</p>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          </div>
        </PremiumGate>
      )}
    </div>
  );
};