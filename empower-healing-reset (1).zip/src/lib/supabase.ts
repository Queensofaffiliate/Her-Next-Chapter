import { createClient } from '@supabase/supabase-js';

// Supabase configuration - use environment variables in production
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://aukemeyyxbbyralenfra.supabase.co';
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF1a2VtZXl5eGJieXJhbGVuZnJhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMwOTQ5NzYsImV4cCI6MjA2ODY3MDk3Nn0.lfGANB8jONVzVWmQnJCDMonrzX-xJmsJ9ecRVTbGl6k';

export const supabase = createClient(supabaseUrl, supabaseKey, {
  global: {
    headers: {
      'X-Client-Info': 'empower-healing-reset@1.0.0'
    }
  },
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
});

// Test connection function
export const testSupabaseConnection = async () => {
  try {
    const { data, error } = await supabase.from('profiles').select('count').limit(1);
    return { success: !error, error: error?.message };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
};

// Database types
export interface Profile {
  id: string;
  email: string;
  full_name?: string;
  subscription_tier: 'free' | 'premium' | 'pro';
  created_at: string;
  updated_at: string;
}

export interface AudioFile {
  id: string;
  title: string;
  description?: string;
  file_url: string;
  category: 'whisper' | 'journey' | 'comfort';
  requires_premium?: boolean;
  created_at: string;
}

export interface DownloadableContent {
  id: string;
  title: string;
  description?: string;
  file_url: string;
  file_type: string;
  requires_premium?: boolean;
  created_at: string;
}