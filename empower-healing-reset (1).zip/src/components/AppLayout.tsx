import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import WelcomeSection from './WelcomeSection';
import NavigationButtons from './NavigationButtons';
import TodaysWhisper from './TodaysWhisper';
import JournalPrompts from './JournalPrompts';
import JourneyPhase from './JourneyPhase';
import ComfortCorner from './ComfortCorner';
import BackgroundMusic from './BackgroundMusic';

const AppLayout: React.FC = () => {
  const [currentSection, setCurrentSection] = useState<string>('home');

  const handleNavigation = (section: string) => {
    setCurrentSection(section);
  };

  const handleBack = () => {
    setCurrentSection('home');
  };

  const renderContent = () => {
    switch (currentSection) {
      case 'whisper':
        return <TodaysWhisper onBack={handleBack} />;
      case 'journey':
        return <JourneyPhase onBack={handleBack} />;
      case 'journal':
        return <JournalPrompts onBack={handleBack} />;
      case 'comfort':
        return <ComfortCorner onBack={handleBack} />;
      default:
        return (
          <>
            <WelcomeSection />
            <NavigationButtons onNavigate={handleNavigation} />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-warm-blush/15 via-lavender-gray/10 to-muted-teal/15">
      <BackgroundMusic />
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {renderContent()}
        
        <div className="mt-12 text-center">
          <Card className="p-4 bg-white/40 border-lavender-gray/30">
            <p className="text-sm text-cocoa-brown/70">
              Created with love by Sandra Daniels — Your guide for rising gently into your next season.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AppLayout;