import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Heart, BookOpen, Wind, Pause, Music } from 'lucide-react';
import TodaysWhisper from './TodaysWhisper';
import JournalPrompts from './JournalPrompts';
import TinyWays from './TinyWays';
import PauseJourney from './PauseJourney';
import LettingGo from './LettingGo';
import BackgroundMusic from './BackgroundMusic';

type ViewType = 'home' | 'whispers' | 'journal' | 'tiny-ways' | 'pause' | 'letting-go';

const SimpleApp: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewType>('home');

  const renderView = () => {
    switch (currentView) {
      case 'whispers':
        return <TodaysWhisper />;
      case 'journal':
        return <JournalPrompts />;
      case 'tiny-ways':
        return <TinyWays />;
      case 'pause':
        return <PauseJourney />;
      case 'letting-go':
        return <LettingGo />;
      default:
        return (
          <div className="space-y-6">
            <Card className="mb-6">
              <CardHeader className="text-center">
                <CardTitle className="text-3xl font-bold text-cocoa-brown">
                  Her Next Chapter
                </CardTitle>
                <p className="text-cocoa-brown/70 mt-2">
                  Your journey of healing and empowerment begins here
                </p>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <p className="text-cocoa-brown">
                  Welcome to a safe space designed for women navigating life after abuse.
                </p>
              </CardContent>
            </Card>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setCurrentView('whispers')}>
                <CardHeader>
                  <CardTitle className="text-lg text-cocoa-brown flex items-center gap-2">
                    <Heart className="h-5 w-5 text-warm-blush" />
                    15 Days of Whispers
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-cocoa-brown/70">
                    10 tiny ways to feel better today - simple practices to nurture yourself
                  </p>
                </CardContent>
              </Card>
              
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setCurrentView('journal')}>
                <CardHeader>
                  <CardTitle className="text-lg text-cocoa-brown flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-warm-blush" />
                    Journal Prompts
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-cocoa-brown/70">
                    Thoughtful prompts for self-reflection and growth
                  </p>
                </CardContent>
              </Card>
              
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setCurrentView('tiny-ways')}>
                <CardHeader>
                  <CardTitle className="text-lg text-cocoa-brown flex items-center gap-2">
                    <Heart className="h-5 w-5 text-warm-blush" />
                    10 Tiny Ways
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-cocoa-brown/70">
                    Small acts of self-care to brighten your day
                  </p>
                </CardContent>
              </Card>
              
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setCurrentView('pause')}>
                <CardHeader>
                  <CardTitle className="text-lg text-cocoa-brown flex items-center gap-2">
                    <Pause className="h-5 w-5 text-warm-blush" />
                    5-Day Pause Journey
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-cocoa-brown/70">
                    A gentle journey to slow down and reconnect
                  </p>
                </CardContent>
              </Card>
              
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setCurrentView('letting-go')}>
                <CardHeader>
                  <CardTitle className="text-lg text-cocoa-brown flex items-center gap-2">
                    <Wind className="h-5 w-5 text-warm-blush" />
                    Letting Go Practice
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-cocoa-brown/70">
                    Release what no longer serves your highest good
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-warm-cream via-soft-peach to-warm-blush p-4">
      <div className="max-w-4xl mx-auto">
        {/* Background Music Controls */}
        <div className="mb-4">
          <BackgroundMusic />
        </div>

        {/* Navigation */}
        {currentView !== 'home' && (
          <div className="mb-6">
            <Button
              variant="outline"
              onClick={() => setCurrentView('home')}
              className="text-cocoa-brown hover:bg-warm-blush/10"
            >
              ← Back to Home
            </Button>
          </div>
        )}

        {/* Content */}
        {renderView()}
      </div>
    </div>
  );
};

export default SimpleApp;