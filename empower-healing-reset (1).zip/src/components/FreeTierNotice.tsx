import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Lock, Crown } from 'lucide-react';

interface FreeTierNoticeProps {
  feature: string;
  className?: string;
}

const FreeTierNotice: React.FC<FreeTierNoticeProps> = ({ feature, className = '' }) => {
  return (
    <Card className={`p-4 bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200 ${className}`}>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <Lock className="w-4 h-4 text-purple-600" />
          <Badge variant="outline" className="text-purple-700 border-purple-300">
            Premium Feature
          </Badge>
        </div>
        <Crown className="w-5 h-5 text-yellow-500" />
      </div>
      
      <div className="mt-3">
        <p className="text-sm text-gray-700">
          <strong>{feature}</strong> is available with a premium subscription.
        </p>
        <p className="text-xs text-gray-600 mt-1">
          Your free account includes limited access to our core features.
        </p>
      </div>
    </Card>
  );
};

export default FreeTierNotice;