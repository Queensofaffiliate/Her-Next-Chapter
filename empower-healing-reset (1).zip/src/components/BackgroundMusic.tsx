import React, { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Volume2, VolumeX, Pause, Play } from 'lucide-react';
import { Slider } from './ui/slider';

interface BackgroundMusicProps {
  className?: string;
}

export const BackgroundMusic: React.FC<BackgroundMusicProps> = ({ className = '' }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState([0.3]);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const musicUrl = 'https://aukemeyyxbbyralenfra.supabase.co/storage/v1/object/public/hernextchapter/Her_Next_Chapter_Background_Music.mp3';

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume[0];
      audioRef.current.loop = true;
    }
  }, [volume, isMuted]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  return (
    <div className={`flex items-center space-x-3 p-3 bg-white/80 rounded-lg border border-warm-blush/30 ${className}`}>
      <audio ref={audioRef} src={musicUrl} preload="metadata" />
      
      <Button
        variant="ghost"
        size="sm"
        onClick={togglePlay}
        className="text-cocoa-brown hover:bg-warm-blush/20"
      >
        {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
      </Button>

      <Button
        variant="ghost"
        size="sm"
        onClick={toggleMute}
        className="text-cocoa-brown hover:bg-warm-blush/20"
      >
        {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
      </Button>

      <div className="flex items-center space-x-2 min-w-[100px]">
        <Slider
          value={volume}
          onValueChange={setVolume}
          max={1}
          step={0.1}
          className="flex-1"
        />
      </div>

      <span className="text-xs text-cocoa-brown/60 whitespace-nowrap">
        Background Music
      </span>
    </div>
  );
};

export default BackgroundMusic;