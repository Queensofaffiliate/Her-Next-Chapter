import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface MainButtonProps {
  icon: string;
  title: string;
  description: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary' | 'accent' | 'teal' | 'rose';
}

const MainButton: React.FC<MainButtonProps> = ({ 
  icon, 
  title, 
  description, 
  onClick, 
  variant = 'primary' 
}) => {
  const getVariantStyles = () => {
    switch (variant) {
      case 'primary':
        return 'bg-gradient-to-br from-warm-blush/25 to-lavender-gray/20 hover:from-warm-blush/35 hover:to-lavender-gray/30 border-warm-blush/40';
      case 'secondary':
        return 'bg-gradient-to-br from-muted-teal/20 to-muted-teal/15 hover:from-muted-teal/30 hover:to-muted-teal/25 border-muted-teal/40';
      case 'accent':
        return 'bg-gradient-to-br from-dusty-gold/20 to-dusty-gold/15 hover:from-dusty-gold/30 hover:to-dusty-gold/25 border-dusty-gold/40';
      case 'teal':
        return 'bg-gradient-to-br from-muted-teal/15 to-muted-teal/10 hover:from-muted-teal/25 hover:to-muted-teal/20 border-muted-teal/30';
      case 'rose':
        return 'bg-gradient-to-br from-soft-rose/20 to-soft-rose/15 hover:from-soft-rose/30 hover:to-soft-rose/25 border-soft-rose/40';
      default:
        return 'bg-gradient-to-br from-warm-blush/25 to-lavender-gray/20 hover:from-warm-blush/35 hover:to-lavender-gray/30 border-warm-blush/40';
    }
  };

  return (
    <Card className={`p-6 cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-105 ${getVariantStyles()}`} onClick={onClick}>
      <div className="flex items-center space-x-4">
        <div className="text-3xl">{icon}</div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-cocoa-brown mb-1">{title}</h3>
          <p className="text-sm text-cocoa-brown/70 leading-relaxed">{description}</p>
        </div>
      </div>
    </Card>
  );
};

export default MainButton;