import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export interface WhisperMessage {
  id: string;
  title: string;
  content: string;
  date: string;
  audio_url?: string;
  created_at: string;
}

export function useWhisperMessages() {
  const [messages, setMessages] = useState<WhisperMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('whisper_messages')
        .select('*')
        .order('date', { ascending: false })
        .limit(1);

      if (error) {
        setError(error.message);
        return;
      }

      setMessages(data || []);
    } catch (err) {
      setError('Failed to fetch whisper messages');
    } finally {
      setLoading(false);
    }
  };

  const getTodaysMessage = () => {
    const today = new Date().toISOString().split('T')[0];
    return messages.find(msg => msg.date === today) || messages[0];
  };

  return {
    messages,
    todaysMessage: getTodaysMessage(),
    loading,
    error,
    refetch: fetchMessages,
  };
}