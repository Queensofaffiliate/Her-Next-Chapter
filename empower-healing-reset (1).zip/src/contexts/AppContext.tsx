import React, { createContext, useContext } from 'react';

interface AppContextType {
  user: null;
}

const AppContext = createContext<AppContextType>({
  user: null
});

export const useAppContext = () => useContext(AppContext);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const value = {
    user: null
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};