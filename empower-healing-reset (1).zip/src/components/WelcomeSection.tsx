import React from 'react';
import { Card } from './ui/card';

const WelcomeSection: React.FC = () => {
  return (
    <div className="text-center space-y-6">
      <div className="space-y-2">
        <h1 className="text-4xl font-bold text-cocoa-brown">Her Next Chapter</h1>
        <p className="text-lg text-cocoa-brown/80">Your gentle guide for rising into your next season</p>
      </div>
      
      <Card className="p-6 bg-gradient-to-br from-warm-blush/20 to-soft-rose/15 border-warm-blush/30">
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-cocoa-brown">Welcome, Beautiful Soul</h2>
          <p className="text-cocoa-brown/80 max-w-2xl mx-auto">
            This is your sacred space for growth, reflection, and gentle transformation. 
            Each section has been crafted with love to support you on your unique journey.
          </p>
        </div>
      </Card>
    </div>
  );
};

export default WelcomeSection;