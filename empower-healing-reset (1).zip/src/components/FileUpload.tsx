import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';

interface FileUploadProps {
  onBack: () => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onBack }) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" onClick={onBack} className="text-cocoa-brown hover:bg-warm-blush/20">
          ← Back
        </Button>
        <h2 className="text-2xl font-semibold text-cocoa-brown">Upload Content</h2>
      </div>
      
      <Card className="p-6 bg-gradient-to-br from-warm-blush/20 to-soft-rose/15 border-warm-blush/30">
        <div className="text-center space-y-4">
          <h3 className="text-xl font-semibold text-cocoa-brown">Upload Your Files</h3>
          <p className="text-cocoa-brown/80 max-w-md mx-auto">
            Upload your personalized content files to unlock the full Her Next Chapter experience.
          </p>
          <Button className="bg-muted-teal hover:bg-muted-teal/90 text-white">
            Choose Files
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default FileUpload;