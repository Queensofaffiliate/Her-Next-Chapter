import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { useJourneyPhases } from '@/hooks/useJourneyPhases';

interface JourneyPhaseProps {
  onBack: () => void;
}

const JourneyPhase: React.FC<JourneyPhaseProps> = ({ onBack }) => {
  const { phases, loading, error } = useJourneyPhases();

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={onBack} className="text-cocoa-brown hover:bg-warm-blush/20">
            ← Back
          </Button>
          <h2 className="text-2xl font-semibold text-cocoa-brown">Journey Phase</h2>
        </div>
        <Card className="p-6 bg-gradient-to-br from-warm-blush/20 to-soft-rose/15 border-warm-blush/30">
          <div className="text-center">
            <p className="text-cocoa-brown">Loading your journey phases...</p>
          </div>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={onBack} className="text-cocoa-brown hover:bg-warm-blush/20">
            ← Back
          </Button>
          <h2 className="text-2xl font-semibold text-cocoa-brown">Journey Phase</h2>
        </div>
        <Card className="p-6 bg-gradient-to-br from-warm-blush/20 to-soft-rose/15 border-warm-blush/30">
          <div className="text-center">
            <p className="text-cocoa-brown">Unable to load journey phases. Please try again later.</p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" onClick={onBack} className="text-cocoa-brown hover:bg-warm-blush/20">
          ← Back
        </Button>
        <h2 className="text-2xl font-semibold text-cocoa-brown">Journey Phase</h2>
      </div>
      
      <div className="space-y-4">
        {phases.map((phase, index) => (
          <Card key={phase.id} className="p-6 bg-gradient-to-br from-warm-blush/20 to-soft-rose/15 border-warm-blush/30">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-deep-teal text-white rounded-full flex items-center justify-center text-sm font-semibold">
                  {index + 1}
                </div>
                <h3 className="text-xl font-semibold text-cocoa-brown">{phase.phase_name}</h3>
              </div>
              <p className="text-cocoa-brown/70 text-sm italic">{phase.description}</p>
              <div 
                className="text-cocoa-brown/80"
                dangerouslySetInnerHTML={{ __html: phase.content }}
              />
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default JourneyPhase;