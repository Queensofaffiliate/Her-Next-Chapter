import React from 'react';
import { useSubscription } from '@/hooks/useSubscription';
import FreeTierNotice from './FreeTierNotice';

interface PremiumGateProps {
  feature: string;
  featureName: string;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

const PremiumGate: React.FC<PremiumGateProps> = ({ 
  feature, 
  featureName, 
  children, 
  fallback 
}) => {
  const { hasFeature, loading } = useSubscription();

  if (loading) {
    return (
      <div className="animate-pulse bg-gray-200 rounded-lg h-32"></div>
    );
  }

  if (!hasFeature(feature)) {
    return fallback || <FreeTierNotice feature={featureName} />;
  }

  return <>{children}</>;
};

export default PremiumGate;