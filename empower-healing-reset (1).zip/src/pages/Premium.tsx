import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useSubscription } from '@/hooks/useSubscription';
import { Check, Crown, Star, Heart } from 'lucide-react';

const Premium: React.FC = () => {
  const { tier, isPremium, loading } = useSubscription();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-warm-blush/15 via-lavender-gray/10 to-muted-teal/15 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-muted-teal mx-auto mb-4"></div>
          <p className="text-cocoa-brown">Loading subscription details...</p>
        </div>
      </div>
    );
  }

  const plans = [
    {
      name: 'Free',
      price: '$0',
      period: 'forever',
      features: [
        'Daily whispers',
        'Basic journal prompts',
        'Limited downloads',
        'Community support'
      ],
      current: tier.name === 'free',
      color: 'bg-lavender-gray'
    },
    {
      name: 'Premium',
      price: '$19',
      period: 'month',
      features: [
        'All free features',
        'Unlimited downloads',
        'Premium audio content',
        'Advanced journal prompts',
        'Comfort corner resources',
        'Priority support'
      ],
      current: tier.name === 'premium',
      color: 'bg-muted-teal',
      popular: true
    },
    {
      name: 'Pro',
      price: '$39',
      period: 'month',
      features: [
        'All premium features',
        'Personalized journey phases',
        'One-on-one coaching calls',
        'Custom content creation',
        'Early access to new features'
      ],
      current: tier.name === 'pro',
      color: 'bg-soft-rose'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-warm-blush/15 via-lavender-gray/10 to-muted-teal/15">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Crown className="w-8 h-8 text-muted-teal mr-2" />
            <h1 className="text-4xl font-bold text-cocoa-brown">Her Next Chapter Premium</h1>
          </div>
          <p className="text-lg text-cocoa-brown/80 max-w-2xl mx-auto">
            Unlock your full potential with premium features designed to support your journey of growth and transformation.
          </p>
        </div>

        {/* Current Plan Status */}
        {isPremium() && (
          <Card className="mb-8 bg-gradient-to-r from-muted-teal/10 to-soft-rose/10 border-muted-teal/30">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-2">
                <Star className="w-6 h-6 text-muted-teal mr-2" />
                <h3 className="text-xl font-semibold text-cocoa-brown">
                  You're on the {tier.name} plan
                </h3>
              </div>
              <p className="text-cocoa-brown/70">
                Thank you for being part of our premium community!
              </p>
            </CardContent>
          </Card>
        )}

        {/* Pricing Plans */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {plans.map((plan) => (
            <Card 
              key={plan.name}
              className={`relative ${plan.current ? 'ring-2 ring-muted-teal shadow-lg' : ''} ${plan.popular ? 'transform scale-105' : ''}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-muted-teal text-white px-4 py-1">
                    Most Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl font-bold text-cocoa-brown">
                  {plan.name}
                </CardTitle>
                <div className="mt-2">
                  <span className="text-4xl font-bold text-cocoa-brown">{plan.price}</span>
                  <span className="text-cocoa-brown/60">/{plan.period}</span>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <Check className="w-5 h-5 text-muted-teal mr-3 flex-shrink-0" />
                      <span className="text-cocoa-brown/80">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className={`w-full ${plan.current ? 'bg-gray-400 cursor-not-allowed' : plan.color} text-white hover:opacity-90`}
                  disabled={plan.current}
                >
                  {plan.current ? 'Current Plan' : `Upgrade to ${plan.name}`}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Benefits Section */}
        <Card className="mb-8 bg-white/50 border-warm-blush/30">
          <CardHeader>
            <CardTitle className="text-2xl text-cocoa-brown text-center flex items-center justify-center">
              <Heart className="w-6 h-6 mr-2 text-soft-rose" />
              Why Choose Premium?
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-cocoa-brown mb-2">Unlimited Access</h4>
                <p className="text-cocoa-brown/70 text-sm">
                  Access all premium content, downloads, and resources without limitations.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-cocoa-brown mb-2">Personalized Journey</h4>
                <p className="text-cocoa-brown/70 text-sm">
                  Get content tailored to your specific life phase and goals.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-cocoa-brown mb-2">Priority Support</h4>
                <p className="text-cocoa-brown/70 text-sm">
                  Get faster responses and dedicated support from our team.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-cocoa-brown mb-2">Exclusive Content</h4>
                <p className="text-cocoa-brown/70 text-sm">
                  Access premium audio content and advanced journal prompts.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Back Button */}
        <div className="text-center">
          <Button 
            onClick={() => window.history.back()}
            variant="outline"
            className="border-muted-teal text-muted-teal hover:bg-muted-teal hover:text-white"
          >
            Back to App
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Premium;