import { useState, useEffect } from 'react';
import { useAuth } from './useAuth';
import { supabase } from '@/lib/supabase';

export interface SubscriptionTier {
  id: string;
  name: 'free' | 'premium' | 'pro';
  features: string[];
}

const SUBSCRIPTION_TIERS: Record<string, SubscriptionTier> = {
  free: {
    id: 'free',
    name: 'free',
    features: ['basic_audio', 'daily_whisper', 'limited_downloads']
  },
  premium: {
    id: 'premium', 
    name: 'premium',
    features: ['basic_audio', 'daily_whisper', 'unlimited_downloads', 'premium_audio', 'comfort_corner']
  },
  pro: {
    id: 'pro',
    name: 'pro', 
    features: ['basic_audio', 'daily_whisper', 'unlimited_downloads', 'premium_audio', 'comfort_corner', 'personalized_journey']
  }
};

export function useSubscription() {
  const { user } = useAuth();
  const [tier, setTier] = useState<SubscriptionTier>(SUBSCRIPTION_TIERS.free);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setTier(SUBSCRIPTION_TIERS.free);
      setLoading(false);
      return;
    }

    fetchUserSubscription();
  }, [user]);

  const fetchUserSubscription = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('subscription_tier')
        .eq('id', user?.id)
        .single();

      if (error || !data) {
        setTier(SUBSCRIPTION_TIERS.free);
      } else {
        setTier(SUBSCRIPTION_TIERS[data.subscription_tier] || SUBSCRIPTION_TIERS.free);
      }
    } catch (err) {
      setTier(SUBSCRIPTION_TIERS.free);
    } finally {
      setLoading(false);
    }
  };

  const hasFeature = (feature: string): boolean => {
    return tier.features.includes(feature);
  };

  const isPremium = (): boolean => {
    return tier.name !== 'free';
  };

  return {
    tier,
    loading,
    hasFeature,
    isPremium,
    refetch: fetchUserSubscription
  };
}