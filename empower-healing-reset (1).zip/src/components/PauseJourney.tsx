import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Pause, Play, RotateCcw, Heart } from 'lucide-react';

const pauseJourneySteps = [
  {
    day: 1,
    title: "Permission to Pause",
    content: "Today, give yourself permission to slow down. You don't have to have it all figured out right now. It's okay to take a breath and simply be where you are.",
    reflection: "What would it feel like to give yourself permission to rest without guilt?"
  },
  {
    day: 2,
    title: "Honoring Your Feelings",
    content: "Your emotions are valid, even the difficult ones. Today, practice sitting with whatever you're feeling without trying to fix or change it immediately.",
    reflection: "What emotions am I avoiding, and how can I show them compassion?"
  },
  {
    day: 3,
    title: "The Art of Letting Go",
    content: "Some things are meant to be released. Today, identify one thing you've been holding onto that no longer serves you. It's okay to let it go.",
    reflection: "What am I ready to release to make space for what's meant for me?"
  },
  {
    day: 4,
    title: "Finding Your Rhythm",
    content: "Life doesn't have to be rushed. Today, find your natural rhythm. Move at a pace that honors your energy and well-being.",
    reflection: "What does my ideal daily rhythm look and feel like?"
  },
  {
    day: 5,
    title: "Embracing the Journey",
    content: "You are exactly where you need to be. Today, practice trusting your path, even when you can't see the whole staircase. Your journey is unfolding perfectly.",
    reflection: "How can I trust my journey more deeply, even in uncertainty?"
  }
];

export const PauseJourney: React.FC = () => {
  const [currentDay, setCurrentDay] = useState(1);
  const [completedDays, setCompletedDays] = useState<number[]>([]);

  const currentStep = pauseJourneySteps.find(step => step.day === currentDay);

  const markComplete = () => {
    if (!completedDays.includes(currentDay)) {
      setCompletedDays(prev => [...prev, currentDay]);
    }
  };

  const nextDay = () => {
    if (currentDay < 5) {
      setCurrentDay(currentDay + 1);
    }
  };

  const prevDay = () => {
    if (currentDay > 1) {
      setCurrentDay(currentDay - 1);
    }
  };

  const resetJourney = () => {
    setCurrentDay(1);
    setCompletedDays([]);
  };

  if (!currentStep) return null;

  return (
    <div className="space-y-6">
      <div className="text-center space-y-3">
        <h2 className="text-2xl font-bold text-cocoa-brown flex items-center justify-center gap-2">
          <Pause className="h-6 w-6 text-warm-blush" />
          5-Day Pause Journey
        </h2>
        <p className="text-cocoa-brown/70 max-w-2xl mx-auto">
          A gentle 5-day journey to help you slow down, reflect, and reconnect with yourself.
        </p>
      </div>

      {/* Progress Indicator */}
      <div className="flex justify-center space-x-2 mb-6">
        {pauseJourneySteps.map((step) => (
          <div
            key={step.day}
            className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
              step.day === currentDay
                ? 'bg-warm-blush text-white'
                : completedDays.includes(step.day)
                ? 'bg-sage-green text-white'
                : 'bg-gray-200 text-gray-600'
            }`}
          >
            {step.day}
          </div>
        ))}
      </div>

      {/* Current Day Content */}
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="text-xl text-cocoa-brown flex items-center justify-between">
            <span>Day {currentStep.day}: {currentStep.title}</span>
            {completedDays.includes(currentDay) && (
              <Heart className="h-5 w-5 text-sage-green fill-current" />
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="prose prose-sm max-w-none">
            <p className="text-cocoa-brown/80 leading-relaxed">
              {currentStep.content}
            </p>
          </div>

          <div className="bg-warm-blush/10 p-4 rounded-lg border border-warm-blush/20">
            <h4 className="font-medium text-cocoa-brown mb-2">Reflection Question:</h4>
            <p className="text-cocoa-brown/80 italic">
              {currentStep.reflection}
            </p>
          </div>

          <div className="flex justify-between items-center pt-4">
            <Button
              variant="outline"
              onClick={prevDay}
              disabled={currentDay === 1}
              className="text-cocoa-brown"
            >
              Previous Day
            </Button>

            <Button
              onClick={markComplete}
              disabled={completedDays.includes(currentDay)}
              className="bg-sage-green hover:bg-sage-green/90 text-white"
            >
              {completedDays.includes(currentDay) ? 'Completed ✓' : 'Mark Complete'}
            </Button>

            <Button
              variant="outline"
              onClick={nextDay}
              disabled={currentDay === 5}
              className="text-cocoa-brown"
            >
              Next Day
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Journey Controls */}
      <div className="flex justify-center space-x-4">
        <Button
          variant="ghost"
          onClick={resetJourney}
          className="text-cocoa-brown hover:bg-warm-blush/10"
        >
          <RotateCcw className="h-4 w-4 mr-2" />
          Restart Journey
        </Button>
      </div>

      {completedDays.length === 5 && (
        <div className="text-center p-6 bg-sage-green/10 rounded-lg border border-sage-green/20">
          <h3 className="text-lg font-bold text-sage-green mb-2">
            🌟 Journey Complete! 🌟
          </h3>
          <p className="text-cocoa-brown/80">
            You've completed your 5-day pause journey. Take a moment to honor how far you've come 
            and the insights you've gained along the way.
          </p>
        </div>
      )}
    </div>
  );
};

export default PauseJourney;