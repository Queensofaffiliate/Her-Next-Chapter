import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';

const TestConnection: React.FC = () => {
  return (
    <Card className="p-6 bg-gradient-to-br from-warm-blush/20 to-soft-rose/15 border-warm-blush/30">
      <div className="text-center space-y-4">
        <h3 className="text-xl font-semibold text-cocoa-brown">Connection Test</h3>
        <p className="text-cocoa-brown/80 max-w-md mx-auto">
          Test your connection to the Her Next Chapter services.
        </p>
        <Button className="bg-muted-teal hover:bg-muted-teal/90 text-white">
          Test Connection
        </Button>
      </div>
    </Card>
  );
};

export default TestConnection;