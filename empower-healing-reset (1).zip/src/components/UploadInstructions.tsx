import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';

interface UploadInstructionsProps {
  onBack: () => void;
}

const UploadInstructions: React.FC<UploadInstructionsProps> = ({ onBack }) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" onClick={onBack} className="text-cocoa-brown hover:bg-warm-blush/20">
          ← Back
        </Button>
        <h2 className="text-2xl font-semibold text-cocoa-brown">Upload Guide</h2>
      </div>
      
      <Card className="p-6 bg-gradient-to-br from-warm-blush/20 to-soft-rose/15 border-warm-blush/30">
        <div className="space-y-4">
          <h3 className="text-xl font-semibold text-cocoa-brown">How to Upload Your Content</h3>
          <div className="text-left text-cocoa-brown/80 space-y-2">
            <p>1. Prepare your personalized files</p>
            <p>2. Use the Upload Content section</p>
            <p>3. Select your files and upload</p>
            <p>4. Enjoy your personalized experience</p>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default UploadInstructions;