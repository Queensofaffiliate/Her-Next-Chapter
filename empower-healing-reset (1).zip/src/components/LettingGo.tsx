import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Wind, Trash2, Heart, Send } from 'lucide-react';

const lettingGoPrompts = [
  "What belief about yourself are you ready to release?",
  "What past mistake are you ready to forgive yourself for?",
  "What expectation of others can you let go of today?",
  "What fear has been holding you back that you're ready to release?",
  "What 'should' or 'must' can you release from your vocabulary?",
  "What comparison to others are you ready to stop making?",
  "What version of yourself are you ready to outgrow?",
  "What control are you ready to surrender to trust the process?",
  "What grudge or resentment are you ready to release for your own peace?",
  "What perfectionist standard can you soften today?"
];

export const LettingGo: React.FC = () => {
  const [currentPrompt, setCurrentPrompt] = useState(0);
  const [writings, setWritings] = useState<string[]>(new Array(lettingGoPrompts.length).fill(''));
  const [releasedItems, setReleasedItems] = useState<number[]>([]);

  const handleWritingChange = (value: string) => {
    const newWritings = [...writings];
    newWritings[currentPrompt] = value;
    setWritings(newWritings);
  };

  const releaseWriting = () => {
    if (writings[currentPrompt].trim()) {
      setReleasedItems(prev => [...prev, currentPrompt]);
      // Clear the writing after releasing
      const newWritings = [...writings];
      newWritings[currentPrompt] = '';
      setWritings(newWritings);
    }
  };

  const nextPrompt = () => {
    if (currentPrompt < lettingGoPrompts.length - 1) {
      setCurrentPrompt(currentPrompt + 1);
    }
  };

  const prevPrompt = () => {
    if (currentPrompt > 0) {
      setCurrentPrompt(currentPrompt - 1);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-3">
        <h2 className="text-2xl font-bold text-cocoa-brown flex items-center justify-center gap-2">
          <Wind className="h-6 w-6 text-warm-blush" />
          Letting Go Practice
        </h2>
        <p className="text-cocoa-brown/70 max-w-2xl mx-auto">
          A sacred space for releasing what no longer serves you. Write it down, then let it go with love.
        </p>
      </div>

      {/* Progress Indicator */}
      <div className="flex justify-center mb-6">
        <div className="text-sm text-cocoa-brown/60">
          Prompt {currentPrompt + 1} of {lettingGoPrompts.length} • 
          {releasedItems.length} items released
        </div>
      </div>

      {/* Current Prompt */}
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="text-lg text-cocoa-brown text-center">
            {lettingGoPrompts[currentPrompt]}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            value={writings[currentPrompt]}
            onChange={(e) => handleWritingChange(e.target.value)}
            placeholder="Write your thoughts here... be honest and gentle with yourself."
            className="min-h-[120px] resize-none border-warm-blush/30 focus:border-warm-blush"
            disabled={releasedItems.includes(currentPrompt)}
          />

          {releasedItems.includes(currentPrompt) ? (
            <div className="text-center p-4 bg-sage-green/10 rounded-lg border border-sage-green/20">
              <Wind className="h-8 w-8 text-sage-green mx-auto mb-2" />
              <p className="text-sage-green font-medium">
                Released with love ✨
              </p>
              <p className="text-cocoa-brown/60 text-sm mt-1">
                You've let this go. Feel the lightness in your heart.
              </p>
            </div>
          ) : (
            <div className="flex justify-center">
              <Button
                onClick={releaseWriting}
                disabled={!writings[currentPrompt].trim()}
                className="bg-warm-blush hover:bg-warm-blush/90 text-white"
              >
                <Send className="h-4 w-4 mr-2" />
                Release This
              </Button>
            </div>
          )}

          <div className="flex justify-between items-center pt-4">
            <Button
              variant="outline"
              onClick={prevPrompt}
              disabled={currentPrompt === 0}
              className="text-cocoa-brown"
            >
              Previous
            </Button>

            <div className="text-center">
              <div className="flex space-x-1">
                {lettingGoPrompts.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      index === currentPrompt
                        ? 'bg-warm-blush'
                        : releasedItems.includes(index)
                        ? 'bg-sage-green'
                        : 'bg-gray-200'
                    }`}
                  />
                ))}
              </div>
            </div>

            <Button
              variant="outline"
              onClick={nextPrompt}
              disabled={currentPrompt === lettingGoPrompts.length - 1}
              className="text-cocoa-brown"
            >
              Next
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Release Summary */}
      {releasedItems.length > 0 && (
        <Card className="max-w-2xl mx-auto bg-sage-green/5 border-sage-green/20">
          <CardHeader>
            <CardTitle className="text-lg text-sage-green flex items-center justify-center gap-2">
              <Heart className="h-5 w-5 fill-current" />
              Your Releasing Journey
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-cocoa-brown/80 mb-4">
              You've released {releasedItems.length} thing{releasedItems.length !== 1 ? 's' : ''} with love and courage. 
              Each release creates space for new growth and possibilities.
            </p>
            <div className="text-sm text-sage-green font-medium">
              "What you let go of has already served its purpose. 
              Trust that what's meant for you will find its way."
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default LettingGo;