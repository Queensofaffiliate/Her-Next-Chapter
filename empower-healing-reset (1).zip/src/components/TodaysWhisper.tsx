import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Heart, Calendar } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface WhisperMessage {
  id: string;
  title: string;
  content: string;
  date: string;
  audio_url?: string;
}

interface TodaysWhisperProps {
  onBack: () => void;
}
export const TodaysWhisper: React.FC<TodaysWhisperProps> = ({ onBack }) => {
  const [todaysWhisper, setTodaysWhisper] = useState<WhisperMessage | null>(null);
  const [dayNumber, setDayNumber] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTodaysWhisper();
  }, []);

  const fetchTodaysWhisper = async () => {
    try {
      // Calculate which day of the 15-day cycle we're on
      const startDate = new Date('2024-01-01'); // App launch date
      const today = new Date();
      const daysSinceStart = Math.floor((today.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      const currentDay = (daysSinceStart % 15) + 1; // 1-15 cycle
      
      setDayNumber(currentDay);

      // Fetch all whispers and select today's
      const { data, error } = await supabase
        .from('whisper_messages')
        .select('*')
        .order('date', { ascending: true });

      if (error) throw error;
      
      if (data && data.length > 0) {
        // Get the whisper for today's cycle day
        const whisperIndex = (currentDay - 1) % data.length;
        setTodaysWhisper(data[whisperIndex]);
      }
    } catch (error) {
      console.error('Error fetching today\'s whisper:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-warm-blush mx-auto"></div>
        <p className="text-cocoa-brown/60 mt-2">Loading today's whisper...</p>
      </div>
    );
  }

  if (!todaysWhisper) {
    return (
      <div className="text-center py-8">
        <Heart className="h-12 w-12 text-warm-blush mx-auto mb-4" />
        <p className="text-cocoa-brown/60">No whisper available for today.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" onClick={onBack} className="text-cocoa-brown hover:bg-warm-blush/20">
          ← Back
        </Button>
        <h2 className="text-2xl font-bold text-cocoa-brown flex items-center gap-2">
          <Heart className="h-6 w-6 text-warm-blush" />
          Today's Whisper
        </h2>
      </div>
      
      <div className="text-center">
        <p className="text-cocoa-brown/70">
          Your gentle daily message to nurture your soul • Day {dayNumber} of 15
        </p>
      </div>

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="text-xl text-cocoa-brown flex items-center justify-between">
            <span>{todaysWhisper.title}</span>
            <div className="flex items-center text-sm text-warm-blush font-medium">
              <Calendar className="h-4 w-4 mr-1" />
              {new Date().toLocaleDateString()}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div 
            className="prose prose-sm max-w-none text-cocoa-brown/80"
            dangerouslySetInnerHTML={{ __html: todaysWhisper.content }}
          />

          <div className="text-center pt-4">
            <div className="flex justify-center space-x-1 mb-3">
              {Array.from({ length: 15 }, (_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index + 1 === dayNumber ? 'bg-warm-blush' : 'bg-gray-200'
                  }`}
                />
              ))}
            </div>
            <p className="text-xs text-cocoa-brown/60">
              Come back tomorrow for your next whisper
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TodaysWhisper;