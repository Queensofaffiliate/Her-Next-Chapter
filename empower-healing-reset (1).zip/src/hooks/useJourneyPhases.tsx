import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export interface JourneyPhase {
  id: string;
  phase_name: string;
  description?: string;
  content?: string;
  audio_url?: string;
  order_index?: number;
  created_at: string;
}

export function useJourneyPhases() {
  const [phases, setPhases] = useState<JourneyPhase[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchPhases();
  }, []);

  const fetchPhases = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('journey_phases')
        .select('*')
        .order('order_index', { ascending: true });

      if (error) {
        setError(error.message);
        return;
      }

      setPhases(data || []);
    } catch (err) {
      setError('Failed to fetch journey phases');
    } finally {
      setLoading(false);
    }
  };

  return {
    phases,
    loading,
    error,
    refetch: fetchPhases,
  };
}