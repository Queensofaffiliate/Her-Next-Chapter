import React from 'react';
import { Button } from './ui/button';

interface NavigationButtonsProps {
  onNavigate: (section: string) => void;
}

const NavigationButtons: React.FC<NavigationButtonsProps> = ({ onNavigate }) => {
  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
        <Button 
          onClick={() => onNavigate('whisper')} 
          className="bg-muted-teal hover:bg-muted-teal/90 text-white h-20 flex flex-col"
        >
          <span className="text-2xl mb-1">💫</span>
          <span>Today's Whisper</span>
        </Button>
        <Button 
          onClick={() => onNavigate('journey')} 
          className="bg-soft-rose hover:bg-soft-rose/90 text-white h-20 flex flex-col"
        >
          <span className="text-2xl mb-1">🌱</span>
          <span>Journey Phase</span>
        </Button>
        <Button 
          onClick={() => onNavigate('journal')} 
          className="bg-warm-blush hover:bg-warm-blush/90 text-white h-20 flex flex-col"
        >
          <span className="text-2xl mb-1">📝</span>
          <span>Journal Prompts</span>
        </Button>
        <Button 
          onClick={() => onNavigate('comfort')} 
          className="bg-lavender-gray hover:bg-lavender-gray/90 text-white h-20 flex flex-col"
        >
          <span className="text-2xl mb-1">🤗</span>
          <span>Comfort Corner</span>
        </Button>
      </div>
      
      <div className="mt-6 text-center">
        <Button 
          onClick={() => window.location.href = '/premium'} 
          className="bg-gradient-to-r from-muted-teal to-soft-rose hover:from-muted-teal/90 hover:to-soft-rose/90 text-white px-8 py-3 rounded-lg font-semibold shadow-lg"
        >
          <span className="text-lg mr-2">👑</span>
          Upgrade to Premium
        </Button>
      </div>
    </>
  );
};

export default NavigationButtons;