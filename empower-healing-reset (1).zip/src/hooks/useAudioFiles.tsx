import { useState, useEffect } from 'react';
import { supabase, AudioFile } from '@/lib/supabase';

export function useAudioFiles(category?: string) {
  const [audioFiles, setAudioFiles] = useState<AudioFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchAudioFiles();
  }, [category]);

  const fetchAudioFiles = async () => {
    try {
      setLoading(true);
      let query = supabase
        .from('audio_files')
        .select('*')
        .order('created_at', { ascending: false });

      if (category) {
        query = query.eq('category', category);
      }

      const { data, error } = await query;

      if (error) {
        setError(error.message);
        return;
      }

      setAudioFiles(data || []);
    } catch (err) {
      setError('Failed to fetch audio files');
    } finally {
      setLoading(false);
    }
  };

  return {
    audioFiles,
    loading,
    error,
    refetch: fetchAudioFiles,
  };
}