import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';

interface ComfortCornerProps {
  onBack: () => void;
}

const ComfortCorner: React.FC<ComfortCornerProps> = ({ onBack }) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" onClick={onBack} className="text-cocoa-brown hover:bg-warm-blush/20">
          ← Back
        </Button>
        <h2 className="text-2xl font-semibold text-cocoa-brown">Comfort Corner</h2>
      </div>
      
      <Card className="p-6 bg-gradient-to-br from-warm-blush/20 to-soft-rose/15 border-warm-blush/30">
        <div className="text-center space-y-4">
          <h3 className="text-xl font-semibold text-cocoa-brown">Your Safe Space</h3>
          <p className="text-cocoa-brown/80 max-w-md mx-auto">
            Welcome to your comfort corner. Here you can find peace, download healing resources, and access soothing audio content.
          </p>
          <div className="mt-6">
            <h4 className="text-lg font-medium text-cocoa-brown mb-3">Available Resources:</h4>
            <div className="space-y-2 text-left">
              <p className="text-cocoa-brown/70">• 10 tiny ways to feel better today</p>
              <p className="text-cocoa-brown/70">• Healing journal templates</p>

              <p className="text-cocoa-brown/70">• Background music for relaxation</p>
            </div>
          </div>
        </div>

      </Card>
    </div>
  );
};

export default ComfortCorner;